import React from 'react';

const Task11 = () => {
  return (
    <div>
      <h2>Hello, React!</h2>
    </div>
  );
};

export default Task11;
