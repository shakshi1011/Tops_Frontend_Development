import React, { Component } from 'react';

class WelcomeMessage extends Component {
  render() {
    return <h2>Welcome to React!</h2>;
  }
}

export default WelcomeMessage;
