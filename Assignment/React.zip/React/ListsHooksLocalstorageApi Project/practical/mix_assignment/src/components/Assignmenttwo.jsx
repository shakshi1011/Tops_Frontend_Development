import Task1 from "../assignment/2/task1";
import Task2 from "../assignment/2/task2";
import Task3 from "../assignment/2/task3";
import Task4 from "../assignment/2/task4";
import Task5 from "../assignment/2/task5";
import Task6 from "../assignment/2/task6";
import Task7 from "../assignment/2/task7";
import Task8 from "../assignment/2/task8";
function assignmenttwo() {
  return (
    <div>
      <div><Task1 /></div>
      <div><Task2 /></div>
      <div><Task3 /></div>
      <div><Task4 /></div>
      <div><Task5 /></div>
      <div><Task6 /></div>
      <div><Task7 /></div>
      <div><Task8 /></div>
    </div>
  );
}

export default assignmenttwo;
