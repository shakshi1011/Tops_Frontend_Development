const LoadingSpinner = () => {
    return <h3 style={{ textAlign: "center" }}>Loading...</h3>;
  };
  
  export default LoadingSpinner;
  